-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 22, 2022 at 04:20 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `system_request`
--

-- --------------------------------------------------------

--
-- Table structure for table `department_type`
--

CREATE TABLE `department_type` (
  `num` int(11) NOT NULL,
  `department_code` int(11) NOT NULL,
  `department_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department_type`
--

INSERT INTO `department_type` (`num`, `department_code`, `department_name`) VALUES
(1, 1, 'CAD/CAM'),
(2, 2, 'HUMAN RESOURCES'),
(3, 3, 'PRODUCTION'),
(4, 4, 'QUALITY CONTROL'),
(5, 5, 'SYSTEM'),
(6, 6, 'PURCHASE'),
(7, 7, 'ACCOUNTING'),
(8, 8, 'SALE'),
(9, 9, 'MACHINE'),
(10, 10, 'FINISHING'),
(11, 11, 'MARKETING'),
(12, 12, 'INTERPRETER');

-- --------------------------------------------------------

--
-- Table structure for table `requested_service`
--

CREATE TABLE `requested_service` (
  `num` int(11) NOT NULL,
  `service_code` int(11) NOT NULL,
  `service_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `requested_service`
--

INSERT INTO `requested_service` (`num`, `service_code`, `service_name`) VALUES
(1, 1, 'New Program'),
(2, 2, 'Revise Program'),
(3, 3, 'Graphic design');

-- --------------------------------------------------------

--
-- Table structure for table `request_db`
--

CREATE TABLE `request_db` (
  `num` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `department_type` int(11) NOT NULL,
  `manager_name` varchar(100) DEFAULT NULL,
  `additional_request` varchar(200) NOT NULL,
  `urgency` int(11) NOT NULL,
  `request_date` datetime NOT NULL DEFAULT current_timestamp(),
  `need_date` date NOT NULL,
  `note` text DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `link-data` text DEFAULT NULL,
  `actual_date` date DEFAULT NULL,
  `requested_service` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request_db`
--

INSERT INTO `request_db` (`num`, `name`, `email`, `department_type`, `manager_name`, `additional_request`, `urgency`, `request_date`, `need_date`, `note`, `status`, `link-data`, `actual_date`, `requested_service`) VALUES
(1, 'chanitra', 'system@samt.co.th', 3, 'horita', 'ttt', 1, '2022-08-16 10:04:02', '2022-08-04', NULL, 2, '', '2022-08-06', 1),
(2, 'chanitra', 'system@samt.co.th', 1, 'horita', 'ttt', 1, '2022-08-04 10:37:03', '2022-08-04', NULL, 1, NULL, '2022-08-05', 1),
(3, 'chanitra', 'system@samt.co.th', 1, 'horita', 'ttt', 1, '2022-08-16 10:02:01', '2022-08-04', NULL, 2, NULL, NULL, 1),
(4, 'chanitra', 'system@samt.co.th', 1, 'horita', 'ttt', 1, '2022-08-16 10:20:23', '2022-08-04', NULL, 3, NULL, NULL, 1),
(5, 'chanitra', 'system@samt.co.th', 1, 'horita', 'ttt', 1, '2022-08-16 10:13:38', '2022-08-04', NULL, 3, NULL, NULL, 1),
(6, 'chanitra', 'system@samt.co.th', 1, 'horita', 'ttt', 1, '2022-08-16 11:04:51', '2022-08-04', NULL, 2, NULL, NULL, 1),
(7, 'chanitra', 'cha.ni.tra@gmail.com', 1, 'TEST', 'TEST', 1, '2022-08-04 15:40:11', '2022-08-31', NULL, 1, NULL, '2022-08-31', 1),
(8, 'ชนิตรา', 'chanitranudchanart@hotmail.com', 3, 'hhhhhhhhhhhh', 'jjjjjjjjjjjjjjjjjjjj', 1, '2022-08-16 10:10:20', '2022-08-27', NULL, 2, NULL, NULL, 1),
(9, 'Natthanita Jitwatthananon', 'Marketing@samt.co.th', 11, 'Horita san.', 'test', 1, '2022-08-10 09:59:08', '2022-08-12', NULL, 1, NULL, NULL, 1),
(10, 'Natthanita Jitwatthananon', 'Marketing@samt.co.th', 11, 'Horita san.', 'test', 1, '2022-08-16 11:05:14', '2022-08-12', 'Test', 2, NULL, NULL, 2),
(11, 'shippo asahi moulds (thailand) co. ltd', 'Natthanita.j@gmail.com', 11, '็Horita', '-', 1, '2022-08-16 13:15:18', '2022-08-17', '8522', NULL, NULL, NULL, 1),
(12, 'ชนิตรา', 'cha.ni.tra@gmail.com', 3, 'hhhhhhhhhhhh', 'jjjjjjjjjjjjjjjjjjjj', 5, '2022-08-16 13:23:09', '2022-08-17', NULL, NULL, NULL, NULL, 3),
(13, 'ณัฏฐานิตา จิตรวัฒนะนนท์', 'Natthanita.j@gmail.com', 11, '็Horita', '-', 1, '2022-08-16 13:25:35', '2022-08-17', '----', NULL, NULL, NULL, 1),
(14, 'ณัฏฐานิตา จิตรวัฒนะนนท์', 'Marketing@samt.co.th', 11, '็Horita', '-', 1, '2022-08-16 13:30:12', '2022-08-17', NULL, NULL, NULL, NULL, 1),
(15, 'Takehome.candle', 'chanitranudchanart@hotmail.com', 1, 'horita1', 'hhh', 1, '2022-08-16 13:40:07', '2022-08-18', NULL, 0, NULL, NULL, 1),
(16, 'chanitra', 'cha.ni.tra@gmail.com', 1, 'TEST', 'TEST', 1, '2022-08-16 13:44:32', '2022-08-17', NULL, 0, NULL, NULL, 1),
(17, 'chanitraฟฟฟฟฟฟฟฟฟฟฟ', 'cha.ni.tra@gmail.com', 1, 'horita1', 'hhh', 1, '2022-08-16 14:10:56', '2022-08-18', NULL, 0, NULL, NULL, 1),
(18, 'chani', 'marketing@samt.co.th', 4, 'horita1', 'TEST', 1, '2022-08-16 14:13:44', '2022-08-17', NULL, 0, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `num` int(11) NOT NULL,
  `status_code` int(11) NOT NULL,
  `status_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`num`, `status_code`, `status_name`) VALUES
(1, 1, 'Success'),
(2, 2, 'Work in process'),
(3, 3, 'Reject'),
(4, 4, 'Wait');

-- --------------------------------------------------------

--
-- Table structure for table `urgency`
--

CREATE TABLE `urgency` (
  `num` int(11) NOT NULL,
  `urgency_code` int(11) NOT NULL,
  `urgency_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `urgency`
--

INSERT INTO `urgency` (`num`, `urgency_code`, `urgency_name`) VALUES
(1, 1, 'Very importance'),
(2, 2, 'High'),
(3, 3, 'Medium'),
(4, 4, 'Low'),
(5, 5, 'Not importance');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department_type`
--
ALTER TABLE `department_type`
  ADD PRIMARY KEY (`num`);

--
-- Indexes for table `requested_service`
--
ALTER TABLE `requested_service`
  ADD PRIMARY KEY (`num`);

--
-- Indexes for table `request_db`
--
ALTER TABLE `request_db`
  ADD PRIMARY KEY (`num`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`num`);

--
-- Indexes for table `urgency`
--
ALTER TABLE `urgency`
  ADD PRIMARY KEY (`num`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `request_db`
--
ALTER TABLE `request_db`
  MODIFY `num` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `num` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
