<?php
include('config.php');

isset($_GET['user_name']) ? $user_name = $_GET['user_name'] : $user_name = "";
if (!empty($user_name)) {
    $name = $user_name;
}
$datas = "SELECT i.id, i.part_id, i.shippo_code, i.part_name, i.qty_max, i.qty_min, i.qty, 
                i.purchese_day, i.i_usage, i.i_unit, i.price, i.type, i.i_status, i.i_check_status, i.send_mail, i.i_create_date,
                m.m_name, m.m_email, m.m_address,
                (SELECT sum(ti.quantity)
                        FROM transection_inventory2 ti
                        WHERE ti.t_status = 'Receiving' and ti.part_id = i.part_id
                        group by part_id
                ) AS receiving,
                (SELECT sum(ti.quantity)
                        FROM transection_inventory2 ti
                        WHERE ti.t_status = 'leave' and ti.part_id = i.part_id
                        group by part_id
                ) AS amount,
                ( SELECT sum(ti.qty_return)
                        FROM project_j.transection_inventory2 ti
                        WHERE ti.t_status = 'Receiving' and ti.part_id = i.part_id
                        group by part_id
                ) AS total_return,
                ( SELECT sum(ti.quantity)
                        FROM project_j.transection_inventory2 ti
                        WHERE ti.t_status = 'reverse' and ti.part_id = i.part_id
                        group by part_id
                ) AS total_reverse
                FROM inventory1 i
                left join maker m 
                on i.m_id = m.m_id;
                -- group BY i.part_id 
            ";
$result = $conn->query($datas);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Project - J</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">

    <!-- Data table -->
    <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css" />
    
</head>

<style>
    table.paleBlueRows {
        font-family: "Times New Roman", Times, serif;
        border: 1px solid #FFFFFF;
        width: 100%;
        height: 200px;
        text-align: center;
        border-collapse: collapse;
    }

    table.paleBlueRows td,
    table.paleBlueRows th {
        border: 1px solid #21130d;
        padding: 3px 2px;
    }

    table.paleBlueRows tbody td {
        font-size: 13px;
    }

    table.paleBlueRows tr:nth-child(even) {
        background: #D0E4F5;
    }

    table.paleBlueRows thead {
        background: #0B6FA4;
        border-bottom: 1px solid #000000;
    }

    table.paleBlueRows thead th {
        font-size: 17px;
        font-weight: bold;
        color: #FFFFFF;
        text-align: center;
        border-left: 1px solid #000000;
    }

    table.paleBlueRows thead th:first-child {
        --bs-table-hover-color: #000000;
        --bs-table-hover-bg: rgb(255 10 10 / 33%);
        /* border-left: none; */
    }

    table.paleBlueRows tfoot {
        font-size: 14px;
        font-weight: bold;
        color: #333333;
        background: #D0E4F5;
        border-top: 3px solid #444444;
    }

    table.paleBlueRows tfoot td {
        font-size: 14px;
    }

    .myButton {
        color: rgb(255, 255, 255);
        font-size: 16px;
        /* line-height: 16px; */
        padding: 6px;
        border-radius: 10px;
        font-family: Georgia, serif;
        font-weight: normal;
        text-decoration: none;
        font-style: normal;
        font-variant: normal;
        text-transform: none;
        /* background-image: linear-gradient(to right, rgb(28, 110, 164) 0%, rgb(35, 136, 203) 50%, rgb(20, 78, 117) 100%);
        box-shadow: rgb(0, 0, 0) 5px 5px 15px 5px;
        border: 1px solid rgb(28, 110, 164); */
        background-image: linear-gradient(to right, rgb(0 0 0) 0%, rgb(1 106 14 / 84%) 50%, rgb(20 117 36) 100%);
        box-shadow: rgb(0 88 197) 5px 5px 15px 5px;
        border: 1px solid rgb(50 164 28);
        display: inline-block;
        margin: -2% 0 -6% 88%;
    }

    .myButton:hover {
        background: #168914;
    }

    .myButton:active {
        background: #144E75;
    }

    input[type=text] {
        width: 80%;
        padding: 5px 0px;
        margin: 8px 0;
        box-sizing: border-box;
        border: 1px solid red;
        border-radius: 4px;
    }

    div.blueTable {
        /* border: 1px solid #1C6EA4; */
        background-color: #ffffff;
        width: 100%;
        text-align: left;
    }

    .divTable.blueTable .divTableCell,
    .divTable.blueTable .divTableHead {
        border: 1px solid #ffffff;
        padding: 3px 1px;
    }

    .divTable.blueTable .divTableBody .divTableCell {
        font-size: 13px;
    }

    .divTable.blueTable .divTableRow:nth-child(even) {
        background: #D0E4F5;
    }

    .blueTable .tableFootStyle {
        font-size: 14px;
    }

    .blueTable .tableFootStyle .links {
        text-align: right;
    }

    .blueTable .tableFootStyle .links a {
        display: inline-block;
        background: #1C6EA4;
        color: #FFFFFF;
        padding: 2px 8px;
        border-radius: 5px;
    }

    .blueTable.outerTableFooter {
        border-top: none;
    }

    .blueTable.outerTableFooter .tableFootStyle {
        padding: 3px 5px;
    }

    /* DivTable.com */
    .divTable {
        display: table;
    }

    .divTableRow {
        display: table-row;
    }

    .divTableHeading {
        display: table-header-group;
    }

    .divTableCell,
    .divTableHead {
        display: table-cell;
    }

    .divTableHeading {
        display: table-header-group;
    }

    .divTableFoot {
        display: table-footer-group;
    }

    .divTableBody {
        display: table-row-group;
    }

    /* css new */
    table.minimalistBlack {
        border: 1px solid #000000;
        width: 100%;
        text-align: left;
        border-collapse: collapse;
        margin: 0 0 0 13px;
    }

    table.minimalistBlack td,
    table.minimalistBlack th {
        border: 1px solid #000000;
        padding: 5px 4px;
    }

    table.minimalistBlack tbody td {
        font-size: 11px;
    }

    table.minimalistBlack thead {
        background: #CFCFCF;
        background: -moz-linear-gradient(top, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
        background: -webkit-linear-gradient(top, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
        background: linear-gradient(to bottom, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
        border-bottom: 1px solid #000000;
    }

    table.minimalistBlack thead th {
        font-size: 11px;
        font-weight: bold;
        color: #000000;
        text-align: left;
    }

    table.minimalistBlack tfoot td {
        font-size: 14px;
    }

    .newdiv {
        margin: -37px 0 0 70%;
    }

    ul.a {
        list-style: none;
        /* Remove HTML bullets */
        padding: 0;
        margin: 0;
    }

    li {
        padding-left: 16px;
    }

    li::before {
        content: "▇";
        padding-right: 8px;
        color: rgb(128, 128, 128, 0.6);
    }

    .li1::before {
        content: "▇";
        padding-right: 8px;
        color: rgb(128, 128, 0, 0.6);
    }

    .li2::before {
        content: "▇";
        padding-right: 8px;
        color: rgb(239, 194, 193, 0.6);
    }

    .li3::before {
        content: "▇";
        padding-right: 8px;
        color: rgb(0, 128, 0, 0.6);

    }

    .li4::before {
        content: "▇";
        padding-right: 8px;
        color: rgb(114, 176, 228, 0.6);

    }

    /* The container */
    .container {
        display: block;
        position: relative;
        padding-left: 35px;
        margin-bottom: 12px;
        cursor: pointer;
        font-size: 22px;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }

    /* Hide the browser's default checkbox */
    .container input {
        position: absolute;
        opacity: 0;
        cursor: pointer;
        height: 0;
        width: 0;
    }

    /* Create a custom checkbox */
    .checkmark {
        position: absolute;
        top: 0;
        left: 0;
        height: 25px;
        width: 25px;
        background-color: #eee;
    }

    /* On mouse-over, add a grey background color */
    .container:hover input~.checkmark {
        background-color: #ccc;
    }

    /* When the checkbox is checked, add a blue background */
    .container input:checked~.checkmark {
        background-color: #2196F3;
    }

    /* Create the checkmark/indicator (hidden when not checked) */
    .checkmark:after {
        content: "";
        position: absolute;
        display: none;
    }

    /* Show the checkmark when checked */
    .container input:checked~.checkmark:after {
        display: block;
    }

    /* Style the checkmark/indicator */
    .container .checkmark:after {
        left: 9px;
        top: 5px;
        width: 5px;
        height: 10px;
        border: solid white;
        border-width: 0 3px 3px 0;
        -webkit-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        transform: rotate(45deg);
    }
    .tr1 {
        margin: 0;
    }
</style>

<body>
    <div class="container-fluid position-relative d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <!-- Sidebar Start -->
        <div class="sidebar pe-4 pb-3">
            <nav class="navbar bg-secondary navbar-dark">
                <a href="#">
                    <!-- <h3 class="text-warning"><i class="fas fa-dragon me-2"></i>Project-J</h3> -->
                    <h3 class="text-warning"><img src="img/logo7.png" alt="" style="width: 223.59px; height: 70px;"></h3>
                </a>
                <div class="navbar-nav w-100">
                    <a href="index.php?user_name=<?php echo $name ?>" class="nav-item nav-link active"><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
                    <a href="create_maker.php?user_name=<?php echo $name ?>" class="nav-item nav-link"><i class="fas fa-edit me-2"></i>Create Maker</a>
                    <a href="create_part.php?user_name=<?php echo $name ?>" class="nav-item nav-link"><i class="fas fa-edit me-2"></i>Create Part</a>
                    <!-- <a href="widget.html" class="nav-item nav-link"><i class="fa fa-th me-2"></i>Widgets</a> -->
                    <a href="inbound.php?user_name=<?php echo $name ?>" class="nav-item nav-link"><i class="fas fa-dolly me-2"></i><span style="font-size: 14px;">Inbound / Outbound</span></a>
                    <a href="#" class="nav-item nav-link"><i class="fa fa-table me-2"></i>Master</a>
                    <!-- <a href="send_mail.php?user_name=<?php echo $name ?>" class="nav-item nav-link"><i class="fa fa-envelope me-2"></i>SendMail</a> -->
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fas fa-file-invoice me-2"></i>Report</a>
                        <div class="dropdown-menu bg-transparent border-0">
                        <a href="report_all.php?user_name=<?php echo $name ?>" class="dropdown-item" style="color: #ffffff;"><i class="fas fa-folder-open me-2"></i>Report All</a>
                            <a href="#" class="dropdown-item" style="color: #ffffff;"><i class="fas fa-redo-alt me-2"></i>Return / ของตีกลับ</a>
                            <a href="#" class="dropdown-item" style="color: #ffffff;"><i class="fas fa-shipping-fast me-2"></i>Receiving /ของรับเข้า</a>
                            <a href="#" class="dropdown-item" style="color: #ffffff;"><i class="fas fa-cart-plus me-2"></i>leave / ของออก</a>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-secondary navbar-dark sticky-top px-4 py-0" style="background-color: #000000;">
                <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
                    <h2 class="text-primary mb-0"><i class="fa fa-user-edit"></i></h2>
                </a>
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <i class="fa fa-bars"></i>
                </a>
                <form class="d-none d-md-flex ms-4">
                    <input class="form-control bg-dark border-0" type="search" placeholder="Search">
                </form>
                <div class="navbar-nav align-items-center ms-auto">
                    <?php
                    $to_date = date("Y-m-d 00:00:00");
                    $from_date = date("Y-m-d 23:59:59");
                    $sql_on_order = "SELECT id, part_id, part_name, i_status, send_mail, create_date
                                        FROM project_j.transection_order
                                        where create_date between ('$to_date') and ('$from_date')
                                        order by create_date desc 
                                        limit 3
                                        ";
                    $data_on_order = $conn->query($sql_on_order);
                    ?>
                    <?php
                    $to_date = date("Y-m-d 00:00:00");
                    $from_date = date("Y-m-d 23:59:59");
                    $sql_maker = "SELECT id, po_maker
                                        FROM transection_po
                                        where po_date_create between ('$to_date') and ('$from_date')
                                        order by po_date_create desc 
                                        limit 3
                                        ";
                    $data_maker = $conn->query($sql_maker);
                    ?>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-bell me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Notificatin</span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-end bg-secondary border-0 rounded-0 rounded-bottom m-0" style="background-color: #000000;">
                            <?php
                            foreach ($data_maker as $key => $val_maker) {
                                $maker = $val_maker['po_maker'];
                            ?>
                                <a href="#" class="dropdown-item">
                                    <h6 class="fw-normal mb-0" style="color: #ffffff;">On Order</h6>
                                    <small><?php echo "Maker : " . $maker ?></small>
                                </a>
                                <hr class="dropdown-divider">
                            <?php
                            }
                            ?>
                            <a href="#" class="dropdown-item text-center">See all notifications</a>
                        </div>

                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <img class="rounded-circle me-lg-2" src="images/admin.png" alt="" style="width: 40px; height: 40px;">
                            <span class="d-none d-lg-inline-flex"><?php echo $name ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-secondary border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">My Profile</a>
                            <a href="#" class="dropdown-item">Settings</a>
                            <a href="logout.php" class="dropdown-item">Log Out</a>
                        </div>
                    </div>
                </div>
            </nav>
            <!-- Navbar End -->
            
            <!-- Table Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="bg-secondary text-center rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h6 class="mb-0">Purchase order Details</h6>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Send Mial</button>
                    </div>
                    <table class="paleBlueRows">
                        <thead>
                            <tr>
                                <th>Part ID</th>
                                <th>Shippo Code</th>
                                <th>Part Name</th>
                                <th>Name Maker</th>
                                <!-- <th>Email</th> -->
                                <th>Status</th>
                                <!-- <th>Receiving</th>  // จำนวนรับเข้าทั้งหมด -->
                                <!-- <th>Amount</th>  // จำนวนออกทั้งหมด -->
                                <th>Current</th>
                                <th>On Order</th>
                                <th>Total</th>
                                <th>Unit</th>
                                <th>Max</th>
                                <th>AP</th>
                                <th>Min</th>
                                <th>Usage</th>
                                <th>type</th>
                                <th style="width: 1%;">Return</th>
                                <th style="width: 1%;">Reverse</th>
                                <th>NG rate</th>
                                <!-- <th>Balance</th> -->
                                <th>Order</th>
                                <th>Check</th>

                            </tr>
                        </thead>

                        <?php
                        foreach ($result as  $data) {

                            $AP = $data['qty_min'] + $data['i_usage'];
                            // echo $data['qty']." | total | ";
                            // $quatiry = $on_order = floor($data['qty_max'] - $data['qty']) / $data['i_unit'];
                            // echo floor($quatiry) * $data['i_unit']." | จำนวนจริง | ";

                            // เช็ค สานถานะ และ จำนวนที่ต้องสั่ง
                            if ($data['qty'] >= $AP) {
                                $status = "in stock"; // in stock
                                $order = 0;
                                $on_order = 0;
                                $unit = "-";
                                $total = $data['qty'];
                            } else if ($data['qty'] < $AP) { // จำนวน total < จำนวนที่ระบบตั้งไว้

                                if ($data['qty'] == 0 and $data['send_mail'] == 1) { // จำนวน qty = 0 ส่งเมล์แล้ว
                                    // echo "ZZZZZ | ".$data['part_id']." ,";
                                    $on_order = floor($data['qty_max'] - $data['qty']) / $data['i_unit']; // ค่า on order
                                    $unit = floor($on_order) * $data['i_unit']; // ค่า unit
                                    $order = 0;
                                    $status = "on order";
                                    $total = $data['qty'] + $unit;
                                } elseif ($data['qty'] != 0 and $data['send_mail'] == 1) { // จำนวน qty != 0 คือมันค่า ส่งเมล์แล้ว
                                    // echo "SSSSS | ".$data['part_id']." ,";
                                    $on_order = floor($data['qty_max'] - $data['qty']) / $data['i_unit']; // ค่า on order
                                    $unit = floor($on_order) * $data['i_unit']; // ค่า unit
                                    $order = 0;
                                    $status = "on order";
                                    $total = $data['qty'] + $unit;
                                } elseif ($data['qty'] == 0 and $data['send_mail'] == 0) { // จำนวน qty = 0 ยังไม่ส่งเมล์
                                    // echo "aaaa | ".$data['part_id']." ,";
                                    $order = floor($data['qty_max'] - $data['qty']) / $data['i_unit']; // ค่า order
                                    $unit = floor($order) * $data['i_unit']; // ค่า unit
                                    $on_order = 0;
                                    $status = "order";
                                    $total = $data['qty'];
                                } elseif ($data['qty'] > 0 and $data['send_mail'] == 0) { // จำนวน qty != 0 คือมันค่า ยังไม่ส่งเมล์
                                    // echo "XXXXX | ".$data['part_id']." ,";
                                    $order = floor($data['qty_max'] - $data['qty']) / $data['i_unit']; // ค่า order
                                    $unit = floor($order) * $data['i_unit']; // ค่า unit
                                    $on_order = 0;
                                    $status = "order";
                                    $total = $data['qty'];
                                }
                            }

                            // ค่า balance
                            $balance = ($part_id = $data['total_return'] - $part_id = $data['total_reverse']);

                            // เช็ค ค่า ng rate 
                            if ($data['total_return'] == 0 and $data['total_return'] == "") {
                                $ng_rate = 0;
                            } else {
                                $ng_rate = ($data['total_return'] / $part_id = $data['receiving']) * 100;
                            }

                            // เช็ค สถานะว่าสั่งซื้อหรือยัง
                            $check_status = "";
                            if ($status == "order" and $total < $AP) {
                                $check_status = "FALSE";
                            } elseif ($status == "order" and $total > $AP) {
                                $check_status = "FALSE";
                            } elseif ($status == "in stock" and $total > $AP) {
                                $check_status = "FALSE";
                            } else {
                                $check_status = "TRUE";
                            }
                        ?>
                            <tbody>
                                <tr>
                                    <td><?php echo $part_id = $data['part_id']; ?></td>
                                    <td><?php echo $data['shippo_code']; ?></td>
                                    <td><?php echo $part_name = $data['part_name']; ?></td>
                                    <td><?php echo $maker_name = $data['m_name']; ?></td>
                                    <!-- <td><?php //echo $email = $data['email_maker'];
                                                ?></td> -->
                                    <?php
                                    if ($status == "in stock") {
                                    ?>
                                        <td style="background: #aef08c"><?php echo $status; ?></td>

                                    <?php
                                    } elseif ($status == "order") {
                                    ?>
                                        <td style="background: #f18787"><?php echo $status; ?></td>
                                    <?php
                                    } else {
                                    ?>
                                        <td style="background: #FFFF00"><?php echo $status; ?></td>
                                    <?php
                                    }
                                    ?>
                                    <!-- <td><?php //echo $receiving = $data['receiving']; 
                                                ?></td>
                                            <td><?php //echo $amount = $data['amount']; 
                                                ?></td> -->
                                    <td><?php echo $cuerrent = $data['qty']; ?></td> <!-- จำนวนปัจจุบัน -->
                                    <!-- ค่า on order -->
                                    <?php if ($data['type'] == "box") {
                                    ?>
                                        <?php
                                        if ($on_order != 0 and $order == 0) { // จำนวนอยู่ใน on_order
                                        ?>
                                            <td style="background: #FFFF00"><?php echo floor($on_order) . "(" . $unit . " ชิ้น)"; ?></td>
                                            <!-- จำนวนในออเดอร์ -->

                                        <?php
                                        } elseif ($on_order == 0 and $order != 0) { // จำนวนอยู่ใน order
                                        ?>
                                            <td style="background: #f18787"><?php echo floor($on_order) . "(" . 0 . " ชิ้น)"; ?></td>
                                            <!-- จำนวนในออเดอร์ -->
                                        <?php
                                        } else {
                                        ?>
                                            <td style="background: #aef08c"><?php echo floor($on_order) . "(" . $unit . " ชิ้น)"; ?></td>
                                            <!-- จำนวนในออเดอร์ -->
                                        <?php
                                        }
                                        ?>
                                    <?php
                                    } elseif ($data['type'] == "kg") {
                                    ?>
                                        <?php
                                        if ($on_order != 0 and $order == 0) { // จำนวนอยู่ใน on_order
                                        ?>
                                            <td style="background: #FFFF00"><?php echo floor($on_order) . "(" . $unit . " กิโล)"; ?></td>
                                            <!-- จำนวนในออเดอร์ -->

                                        <?php
                                        } elseif ($on_order == 0 and $order != 0) { // จำนวนอยู่ใน order
                                        ?>
                                            <td style="background: #f18787"><?php echo floor($on_order) . "(" . 0 . " กิโล)"; ?></td>
                                            <!-- จำนวนในออเดอร์ -->
                                        <?php
                                        } else {
                                        ?>
                                            <td style="background: #aef08c"><?php echo floor($on_order) . "(" . $unit . " กิโล)"; ?></td>
                                            <!-- จำนวนในออเดอร์ -->
                                        <?php
                                        }
                                        ?>
                                    <?php
                                    } elseif ($data['type'] == "wire") {
                                    ?>
                                        <?php
                                        if ($on_order != 0 and $order == 0) { // จำนวนอยู่ใน on_order
                                        ?>
                                            <td style="background: #FFFF00"><?php echo floor($on_order) . "(" . $unit . " เส้น)"; ?></td>
                                            <!-- จำนวนในออเดอร์ -->

                                        <?php
                                        } elseif ($on_order == 0 and $order != 0) { // จำนวนอยู่ใน order
                                        ?>
                                            <td style="background: #f18787"><?php echo floor($on_order) . "(" . 0 . " เส้น)"; ?></td>
                                            <!-- จำนวนในออเดอร์ -->
                                        <?php
                                        } else {
                                        ?>
                                            <td style="background: #aef08c"><?php echo floor($on_order) . "(" . $unit . " เส้น)"; ?></td>
                                            <!-- จำนวนในออเดอร์ -->
                                        <?php
                                        }
                                        ?>
                                    <?php
                                    } else {
                                    ?>
                                        <?php
                                        if ($on_order != 0 and $order == 0) { // จำนวนอยู่ใน on_order
                                        ?>
                                            <td style="background: #FFFF00"><?php echo floor($on_order) . "(" . $unit . " ถุง)"; ?></td>
                                            <!-- จำนวนในออเดอร์ -->

                                        <?php
                                        } elseif ($on_order == 0 and $order != 0) { // จำนวนอยู่ใน order
                                        ?>
                                            <td style="background: #f18787"><?php echo floor($on_order) . "(" . 0 . " ถุง)"; ?></td>
                                            <!-- จำนวนในออเดอร์ -->
                                        <?php
                                        } else {
                                        ?>
                                            <td style="background: #aef08c"><?php echo floor($on_order) . "(" . $unit . " ถุง)"; ?></td>
                                            <!-- จำนวนในออเดอร์ -->
                                        <?php
                                        }
                                        ?>
                                    <?php
                                    }
                                    ?>

                                    <td><?php echo $total ?></td> <!-- จำนวนปัจจุบัน + จำนวนในออเดอร์ -->

                                    <?php
                                    if ($data['type'] == "box") {
                                    ?>
                                        <td style="color: #f32222"><?php echo $qty_max = $data['i_unit'] . " ชิ้น"; ?></td>
                                    <?php
                                    } elseif ($data['type'] == "kg") {
                                    ?>
                                        <td style="color: #f32222"><?php echo $qty_max = $data['i_unit'] . " กิโล"; ?></td>
                                    <?php
                                    } elseif ($data['type'] == "wire") {
                                    ?>
                                        <td style="color: #f32222"><?php echo $qty_max = $data['i_unit'] . " เส้น"; ?></td>
                                    <?php
                                    } else {
                                    ?>
                                        <td style="color: #f32222"><?php echo $qty_max = $data['i_unit'] . " ถุง"; ?></td>
                                    <?php
                                    }
                                    ?>
                                    <td><?php echo $qty_max = $data['qty_max']; ?></td>
                                    <td style="color: #f32222"><?php echo $AP ?></td>
                                    <td><?php echo $qty_min = $data['qty_min']; ?></td>
                                    <td style="color: #f32222"><?php echo $data['i_usage'] ?></td>

                                    <?php
                                    if ($data['type'] == "box") {
                                    ?>
                                        <td style="background-color: rgb(128, 128, 128, 0.6)">BOX</td>
                                    <?php
                                    } elseif ($data['type'] == "kg") {
                                    ?>
                                        <td style="background-color: rgb(128, 128, 0, 0.6)">KG</td>
                                    <?php
                                    } elseif ($data['type'] == "wire") {
                                    ?>
                                        <td style="background-color: rgb(239, 194, 193, 0.6)">WIRE</td>
                                    <?php
                                    } else {
                                    ?>
                                        <td style="background-color: rgb(0, 128 , 0 , 0.6)">BAG</td>
                                    <?php
                                    }
                                    ?>

                                    <td style="width: 1%;"><?php echo $total_return = $data['total_return']; ?></td>
                                    <td style="width: 1%;"><?php echo $total_reverse = $data['total_reverse']; ?></td>
                                    <td><?php echo round($ng_rate, 2) . "%"; ?></td>
                                    <!-- <td><?php //echo $balance; 
                                                ?></td> -->

                                    <!-- ค่า order -->
                                    <?php
                                    if ($data['type'] == "box") {
                                    ?>
                                        <?php
                                        if ($on_order != 0 and $order == 0) { // จำนวนอยู่ใน on_order
                                        ?>
                                            <td style="background: #FFFF00"><?php echo floor($order) . "(" . 0 . " ชิ้น)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->
                                        <?php
                                        } elseif ($on_order == 0 and $order != 0) { // จำนวนอยู่ใน order
                                        ?>
                                            <td style="background: #f18787"><?php echo floor($order) . "(" . $unit . " ชิ้น)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->
                                        <?php
                                        } else { // ใน stcok เหลืออยู่
                                        ?>
                                            <td style="background: #aef08c"><?php echo floor($order) . "(" . $unit . " ชิ้น)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->
                                        <?php
                                        }
                                        ?>
                                    <?php
                                    } else {
                                    ?>
                                        <?php
                                        if ($on_order != 0 and $order == 0) { // จำนวนอยู่ใน on_order
                                        ?>
                                            <td style="background: #FFFF00"><?php echo floor($order) . "(" . 0 . " ถุง)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->
                                        <?php
                                        } elseif ($on_order == 0 and $order != 0) { // จำนวนอยู่ใน order
                                        ?>
                                            <td style="background: #f18787"><?php echo floor($order) . "(" . $unit . " ถุง)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->
                                        <?php
                                        } else { // ใน stcok เหลืออยู่
                                        ?>
                                            <td style="background: #aef08c"><?php echo floor($order) . "(" . $unit . " ถุง)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->
                                        <?php
                                        }
                                        ?>
                                    <?php
                                    }
                                    ?>

                                    <td><?php echo $check_status; ?></td>
                                </tr>
                            </tbody>
                        <?php
                        }
                        ?>
                    </table>
                </div>
            </div>
            <!-- Table End -->
            <div style="padding: 0 0 0 6px;">
                <h4>TYPE.</h4>
                <ul class="a">
                    <li>รับเป็นกล่อง มีจำนวนเป็นชิ้น</li>
                </ul>
                <ul class="a">
                    <li class="li1">รับเป็นกิโลกรัม มีจำนวนเป็นกิโลกรัม และ รับเป็นถุง มีจำนวนเป็นกิโลกรัม</li>
                </ul>
                <ul class="a">
                    <li class="li2">รับเป็นกิโลกรัม มีจำนวนเป็นเส้น</li>
                </ul>
                <ul class="a">
                    <li class="li3">รับเป็นโลกรัม มีจำนวนเป็นถุง</li>
                </ul>
            </div>

            <!-- modal -->
            <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">SEARCH</h4>
                </div>
                <div class="modal-body">
                    <div class="divTable blueTable">
                        <div class="divTableBody">
                            <div class="divTableRow">
                                <div class="newdiv">
                                    <div class="divTableCell">
                                        <!-- <br> -->
                                        <!-- <button type="button" class="myButton" data-toggle="modal" onclick="myFunction()">Send Mial</button>&nbsp&nbsp&nbsp&nbsp
                                        <button type="button" class="myButton" data-toggle="modal" data-target="#myModal">Clear</button> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- DATA -->
                <!-- <form action="send_mail.php?user_name=<?php echo $name ?>" name="frmAdd" method="post"> -->
                <form action="test_pdf.php?user_name=<?php echo $name ?>" name="frmAdd" method="post">
                    <table id="myTable" class="minimalistBlack" style="width: 96%;">
                        <thead>
                            <tr>
                                <th class="">
                                    <div align="center">
                                        <input name="CheckAll" type="checkbox" id="CheckAll" value="Y" onClick="ClickCheckAll(this);">
                                    </div>
                                </th>
                                <th>Part ID</th>
                                <th>Part Name</th>
                                <th>Name Maker</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th>Order</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $datas2 = "SELECT i.id, i.part_id, i.shippo_code, i.part_name, i.qty_max, i.qty_min, i.qty, 
                                                i.purchese_day, i.i_usage, i.i_unit, i.price, i.type, i.i_status, i.i_check_status, i.send_mail, i.i_create_date,
                                                m.m_name, m.m_email, m.m_address,
                                                (SELECT sum(ti.quantity)
                                                        FROM transection_inventory ti
                                                        WHERE ti.t_status = 'Receiving' and ti.part_id = i.part_id
                                                        group by part_id
                                                ) AS receiving,
                                                (SELECT sum(ti.quantity)
                                                        FROM transection_inventory ti
                                                        WHERE ti.t_status = 'leave' and ti.part_id = i.part_id
                                                        group by part_id
                                                ) AS amount,
                                                ( SELECT sum(ti.qty_return)
                                                        FROM project_j.transection_inventory ti
                                                        WHERE ti.t_status = 'Receiving' and ti.part_id = i.part_id
                                                        group by part_id
                                                ) AS total_return,
                                                ( SELECT sum(ti.quantity)
                                                        FROM project_j.transection_inventory ti
                                                        WHERE ti.t_status = 'reverse' and ti.part_id = i.part_id
                                                        group by part_id
                                                ) AS total_reverse
                                                FROM inventory1 i
                                                left join maker m 
                                                on i.m_id = m.m_id
                                                WHERE i.i_status = 'order'
                                                -- group BY i.part_id 
                                        ";
                            $result = $conn->query($datas2);

                            // $send = "send_mail";
                            $i = 0;
                            foreach ($result as  $data2) {
                                $i++;
                                // $send_mail = $send;

                                $AP1 = $data2['qty_min'] + $data2['i_usage'];
                                // เช็ค สานถานะ และ จำนวนที่ต้องสั่ง
                                if ($data2['qty'] >= $AP1) {
                                    $status = "in stock"; // in stock
                                    $order = "-";
                                    $on_order = null;
                                    $unit = "-";
                                    $total = $data2['qty'];
                                } else if ($data2['qty'] < $AP1) { // จำนวน total < จำนวนที่ระบบตั้งไว้

                                    if ($data2['qty'] == 0 and $data2['send_mail'] == 1) { // จำนวน qty = 0 ส่งเมล์แล้ว
                                        // echo "ZZZZZ | ".$data['part_id']." ,";
                                        $on_order = floor($data2['qty_max'] - $data2['qty']) / $data2['i_unit']; // ค่า on order
                                        $unit = floor($on_order) * $data2['i_unit']; // ค่า unit
                                        $order = 0;
                                        $status = "on order";
                                        $total = $data2['qty'] + $unit;
                                    } elseif ($data2['qty'] != 0 and $data2['send_mail'] == 1) { // จำนวน qty != 0 คือมันค่า ส่งเมล์แล้ว
                                        // echo "SSSSS | ".$data['part_id']." ,";
                                        $on_order = floor($data2['qty_max'] - $data2['qty']) / $data2['i_unit']; // ค่า on order
                                        $unit = floor($on_order) * $data2['i_unit']; // ค่า unit
                                        $order = 0;
                                        $status = "on order";
                                        $total = $data2['qty'] + $unit;
                                    } elseif ($data2['qty'] == 0 and $data2['send_mail'] == 0) { // จำนวน qty = 0 ยังไม่ส่งเมล์
                                        // echo "aaaa | ".$data['part_id']." ,";
                                        $order = floor($data2['qty_max'] - $data2['qty']) / $data2['i_unit']; // ค่า order
                                        $unit = floor($order) * $data2['i_unit']; // ค่า unit
                                        $on_order = 0;
                                        $status = "order";
                                        $total = $data2['qty'];
                                    } elseif ($data2['qty'] > 0 and $data2['send_mail'] == 0) { // จำนวน qty != 0 คือมีค่า ยังไม่ส่งเมล์
                                        // echo "XXXXX | ".$data['part_id']." ,";
                                        $order = floor($data2['qty_max'] - $data2['qty']) / $data2['i_unit']; // ค่า order
                                        $unit = floor($order) * $data2['i_unit']; // ค่า unit
                                        $on_order = 0;
                                        $status = "order";
                                        $total = $data2['qty'];
                                    }
                                }
                                // ค่า balance
                                $balance = ($part_id = $data2['total_return'] - $part_id = $data2['total_reverse']);
                                // เช็ค ค่า ng rate 
                                if ($data2['total_return'] == 0 and $data2['total_return'] == "") {
                                    $ng_rate = 0;
                                } else {
                                    $ng_rate = ($data2['total_return'] / $part_id = $data2['receiving']) * 100;
                                }
                                // เช็ค สถานะว่าสั่งซื้อหรือยัง
                                $check_status = "";
                                $check_status = "";
                                if ($status == "order" and $total < $AP1) {
                                    $check_status = "FALSE";
                                } elseif ($status == "order" and $total > $AP1) {
                                    $check_status = "FALSE";
                                } elseif ($status == "in stock" and $total > $AP1) {
                                    $check_status = "FALSE";
                                } else {
                                    $check_status = "TRUE";
                                }
                            ?>
                                <tr>
                                    <td align="center"><input type="checkbox" name="chkDel[]" id="chkDel<?= $i; ?>" value="<?= $data2["part_id"]?>"></td>
                                    <td><?php echo $data2['part_id']; ?></td>
                                    <td><?php echo $part_name = $data2['part_name']; ?></td>
                                    <td><?php echo $maker_name = $data2['m_name']; ?></td>
                                    <td><?php echo $email = $data2['m_email']; ?></td>
                                    <?php
                                    if ($status == "in stock") {
                                    ?>
                                        <td style="background: #aef08c; width: 20px "><?php echo $status; ?></td>

                                    <?php
                                    } elseif ($status == "order") {
                                    ?>
                                        <td style="background: #f18787; width: 20px"><?php echo $status; ?></td>
                                    <?php
                                    } else {
                                    ?>
                                        <td style="background: #FFFF00; width: 20px"><?php echo $status; ?></td>
                                    <?php
                                    }
                                    ?>

                                    <!-- ค่า order -->
                                    <?php
                                    if ($data2['type'] == "box") {
                                    ?>
                                        <?php
                                        if ($on_order != 0 and $order == 0) { // จำนวนอยู่ใน on_order
                                        ?>
                                            <td style="background: #FFFF00"><?php echo floor($order) . "(" . 0 . " ชิ้น)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->

                                        <?php
                                        } elseif ($on_order == 0 and $order != 0) { // จำนวนอยู่ใน order
                                        ?>
                                            <td style="background: #f18787" width="15%"><input name="qty[]" id="qty<?= $i; ?>" value="<?php echo floor($order)?>" hidden><?php echo floor($order) . "(" . $unit . " ชิ้น)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->
                                        <?php
                                        } else { // ใน stcok เหลืออยู่
                                        ?>
                                            <td style="background: #aef08c"><?php echo floor($order) . "(" . $unit . " ชิ้น)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->
                                        <?php
                                        }
                                        ?>
                                    <?php
                                    } elseif ($data2['type'] == "kg") {
                                    ?>
                                        <?php
                                        if ($on_order != 0 and $order == 0) { // จำนวนอยู่ใน on_order
                                        ?>
                                            <td style="background: #FFFF00" ><?php echo floor($order) . "(" . 0 . " กิโล)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->

                                        <?php
                                        } elseif ($on_order == 0 and $order != 0) { // จำนวนอยู่ใน order
                                        ?>
                                            <td style="background: #f18787" width="15%"><input name="qty[]" id="qty<?= $i; ?>" value="<?php echo floor($order)?>" hidden><?php echo floor($order) . "(" . $unit . " กิโล)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->
                                        <?php
                                        } else { // ใน stcok เหลืออยู่
                                        ?>
                                            <td style="background: #aef08c"><?php echo floor($order) . "(" . $unit . " กิโล)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->
                                        <?php
                                        }
                                        ?>
                                    <?php
                                    } elseif ($data2['type'] == "wire") {
                                    ?>
                                        <?php
                                        if ($on_order != 0 and $order == 0) { // จำนวนอยู่ใน on_order
                                        ?>
                                            <td style="background: #FFFF00"><?php echo floor($order) . "(" . 0 . " เส้น)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->

                                        <?php
                                        } elseif ($on_order == 0 and $order != 0) { // จำนวนอยู่ใน order
                                        ?>
                                            <td style="background: #f18787" width="15%"><input name="qty[]" id="qty<?= $i; ?>" value="<?php echo floor($order)?>" hidden><?php echo floor($order) . "(" . $unit . " เส้น)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->
                                        <?php
                                        } else { // ใน stcok เหลืออยู่
                                        ?>
                                            <td style="background: #aef08c"><?php echo floor($order) . "(" . $unit . " เส้น)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->
                                        <?php
                                        }
                                        ?>
                                    <?php
                                    }else {
                                    ?>
                                        <?php
                                        if ($on_order != 0 and $order == 0) { // จำนวนอยู่ใน on_order
                                        ?>
                                            <td style="background: #FFFF00"><?php echo floor($order) . "(" . 0 . " ถุง)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->

                                        <?php
                                        } elseif ($on_order == 0 and $order != 0) { // จำนวนอยู่ใน order
                                        ?>
                                            <td style="background: #f18787" width="15%"><input name="qty[]" id="qty<?= $i; ?>" value="<?php echo floor($order)?>" hidden><?php echo floor($order) . "(" . $unit . " ถุง)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->
                                        <?php
                                        } else { // ใน stcok เหลืออยู่
                                        ?>
                                            <td style="background: #aef08c"><?php echo floor($order) . "(" . $unit . " ถุง)"; ?></td>
                                            <!-- จำนวนออเดอร์ -->
                                        <?php
                                        }
                                        ?>
                                    <?php
                                    }
                                    ?>
                                </tr>

                            <?php
                            }
                            ?>

                        </tbody>
                    </table>

                    <div class="modal-footer">
                        <input type="reset" value="Reset"> <!-- ปุ่มสำหรับ reset -->
                        <!-- <input type="submit" value="submit" onclick="myFunction()"> ปุ่มสำหรับ ส่งเมล์ -->
                        <input type="submit" name="submit" value="submit">
                        <input type="hidden" name="hdnCount" value="<?= $i; ?>"> <!-- ปุ่มสำหรับ กดเลือกทั้งหทด ซ่อนอยู่ -->
                    </div>
                </form>
            </div>

        </div>
    </div>

            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="bg-secondary rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; <a href="#">Shipo Asahi</a>, All Right Reserved.
                        </div>
                        <div class="col-12 col-sm-6 text-center text-sm-end">
                            <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                            Designed By Shippo Dev</a>
                            <!-- <br>Distributed By: <a href="https://themewagon.com" target="_blank">ThemeWagon</a> -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script type="text/javascript" src="DataTables/datatables.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    <script language="JavaScript">
        $(document).ready(function() {
            $("#myTable").DataTable();
        });

        function ClickCheckAll(vol) {
            var i = 1;
            for (i = 1; i <= document.frmAdd.hdnCount.value; i++) {
                if (vol.checked == true) {
                    // eval("document.frmAdd.chkDel" + i + ".checked=true");
                    $("input[type='checkbox']" ).prop('checked',true)
                } else {
                    // eval("document.frmAdd.chkDel" + i + ".checked=false");
                    $("input[type='checkbox']" ).prop('checked',false)
                }
            }
        }
    </script>
</body>

</html>