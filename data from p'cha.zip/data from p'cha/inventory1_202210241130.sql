INSERT INTO project_j.inventory1 (part_id,shippo_code,part_name,email_maker,name_maker,maker_address,qty_max,i_ap,qty_min,qty,purchese_day,i_usage,i_unit,price,`type`,i_status,i_check_status,send_mail,i_create_date) VALUES
	 (301999,'301999','AZUMA','chanitra@gmail.com','chanitra','SUMIPOL CORPORATION LIMITED
284 ON-NUT RROAD,KWAENG
PRAWET, KHET PRAWET, BANGKOK',120,0,50,0,'0',14,'12',159,'box','order',0,0,'2022-10-20 11:26:18'),
	 (301020,'301020','MILLINGB-36','chanitra@gmail.com','chanitra','SUMIPOL CORPORATION LIMITED
284 ON-NUT RROAD,KWAENG
PRAWET, KHET PRAWET, BANGKOK',200,0,50,200,'0',20,'24',250,'box','in stock',0,0,'2022-10-20 11:26:18'),
	 (301021,'301021','Test001','anucha@gmail.com','anucha','ANUCHA CORPORATION LIMITED
284 ON-NUT RROAD,KWAENG
PRAWET, KHET PRAWET, BANGKOK',500,0,80,0,'0',60,'24',199,'wire','order',0,0,'2022-10-20 11:26:18'),
	 (301022,'301022','Test002','anucha@gmail.com','anucha','ANUCHA CORPORATION LIMITED
284 ON-NUT RROAD,KWAENG
PRAWET, KHET PRAWET, BANGKOK',300,0,60,0,'0',20,'12',1999,'box','order',0,0,'2022-10-20 11:26:18'),
	 (301023,'301023','Test003','anucha@gmail.com','anucha','ANUCHA CORPORATION LIMITED
284 ON-NUT RROAD,KWAENG
PRAWET, KHET PRAWET, BANGKOK',180,0,50,0,'0',20,'5',50,'kg','order',0,0,'2022-10-20 11:26:18'),
	 (301024,'301024','Test004','natta@gmail.com','natta','NATTA CORPORATION LIMITED
284 ON-NUT RROAD,KWAENG
PRAWET, KHET PRAWET, BANGKOK',200,0,40,0,'0',20,'5',599,'bag','order',0,0,'2022-10-20 11:26:18'),
	 (301025,'301025','Test005','nattanita@gmail.com','nattanita','NATTANITA CORPORATION LIMITED
284 ON-NUT RROAD,KWAENG
PRAWET, KHET PRAWET, BANGKOK',100,0,40,0,'0',10,'25',3000,'wire','order',0,0,'2022-10-20 11:26:18'),
	 (301026,'301026','Test006','nattanita@gmail.com','nattanita','NATTANITA CORPORATION LIMITED
284 ON-NUT RROAD,KWAENG
PRAWET, KHET PRAWET, BANGKOK',100,0,40,0,'0',10,'25',500,'kg','order',0,0,'2022-10-20 11:26:18'),
	 (301027,'301027','Test007','kenji@gmail.com','kenji','KENJI CORPORATION LIMITED
284 ON-NUT RROAD,KWAENG
PRAWET, KHET PRAWET, BANGKOK',200,0,40,0,'0',20,'5',1200,'bag','order',0,0,'2022-10-20 11:26:18'),
	 (301028,'301028','Test008','tomiyasu@gmail.com','tomiyasu','TOMOYASU CORPORATION LIMITED
284 ON-NUT RROAD,KWAENG
PRAWET, KHET PRAWET, BANGKOK',100,0,20,0,'0',20,'5',999,'kg','order',0,0,'2022-10-20 11:26:18');
