INSERT INTO project_j.transection_order (part_id,part_name,i_status,send_mail,create_date) VALUES
	 (512004,'COUPLER 65SN "NITTO"','on order',1,'2023-01-04 09:41:45'),
	 (512012,'COUPLER 30PH','on order',1,'2023-01-04 14:46:31');
